package com.company;

import java.util.ArrayList;
import java.util.Scanner;

class Customer{
    int Id;
    String Name;
    ArrayList<Car> CarList ;
    Customer() {
        Scanner obj1=new Scanner(System.in);
        Scanner obj2=new Scanner(System.in);
        System.out.println("Add Id for new customer");
       Id=obj1.nextInt();
       System.out.println("Enter name for new Customer ");
        Name=obj2.nextLine();
        CarList=new ArrayList<>();
    }
    Customer(int Id,String Name,ArrayList<Car> carList){
        this.Id=Id;
        this.Name=Name;
        this.CarList=carList;
    }
    public int getId() {
        return Id;
    }
    public String getName() {
        return Name;
    }
    public ArrayList<Car> getCarList() {
        return CarList;
    }
    public void setCarList( ArrayList<Car> carList){
        this.CarList=carList;
    }
}
