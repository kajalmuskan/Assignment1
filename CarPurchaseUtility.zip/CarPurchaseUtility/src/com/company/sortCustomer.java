package com.company;

import java.util.Comparator;

class sortCustomer implements Comparator<Customer>
{
    public int compare(Customer id, Customer cid){
        return  id.Id-cid.Id;
    }
}