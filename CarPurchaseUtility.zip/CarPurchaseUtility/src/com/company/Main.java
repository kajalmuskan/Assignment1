package com.company;

import java.util.*;

/**
 *This is the Admin page i.e. Main class it contains all the logical part of the assignment
 */
public class Main
   {

       public static void main(String args[])
    {
        ArrayList<Customer> list=new ArrayList<Customer>();
        ArrayList<Random> list2 = new ArrayList<Random>();
        Scanner admin = new Scanner(System.in);

        Scanner sc = new Scanner(System.in);
        System.out.println("........WELCOME....... ");
        System.out.println("Car Purchase Utility Company");
        System.out.println("Enter your Admin ID and their password");
        String admin_id = admin.nextLine();
        String admin_password = admin.nextLine();
        int admin_input;
        if(admin_id.equals("admin")&&admin_password.equals("admin"))
        {
            Scanner admin_login = new Scanner(System.in);
            do {
                System.out.println("Welcome");
                System.out.println("Choose any no. between them");
                System.out.println("1.Add new customer");
                System.out.println("2.Add new car to exiting customer");
                System.out.println("3.List of all customers with their cars details and resale price of car in sorted list");
                System.out.println("4.To check list of all customer with their individuals ID ");
                System.out.println("5.Generate prizes for the customer");
                System.out.println("6.Exit");
                admin_input = admin_login.nextInt();
                switch (admin_input)
                {
                    case 1:
                            list.add(new Customer());
                            break;
                    case 2:

                        System.out.println("Enter the Customer Id");
                        int id=sc.nextInt();
//                        if (sc.hasNextInt()){
//                            id= sc.nextInt();
//                        }

                        System.out.println("1  for  Maruti");
                        System.out.println("2  for  Toyota");
                        System.out.println("3  for  Hyundai");
                        System.out.println("enter car type");
                       int carManufacturer=sc.nextInt();

//                        if (sc.hasNextInt()){
//                            carManufacturer = sc.nextInt();
//                        }


                        int carId=0;
                        Scanner scanner1 =new Scanner(System.in);

                        System.out.println("Enter the Car Id");
                        carId = (new Scanner(System.in)).nextInt();

                        System.out.println("Enter the car model");
                        String carModel = (new Scanner(System.in)).nextLine();
                        System.out.println("Enter car price");
                        int carPrice = (new Scanner(System.in)).nextInt();

                        for(int j=0;j<list.size();j++)
                        {
                            if(id==list.get(j).getId()){
                                Customer c=list.get(j);
                                ArrayList<Car> listofCars=c.getCarList();
                                Car newCar=null;
                                if(carManufacturer==1){
                                    newCar=new Maruti(carId,carModel,carPrice);
                                }else if(carManufacturer==2){
                                    newCar=new Toyota(carId,carModel,carPrice);
                                }else if(carManufacturer==3){
                                    newCar=new Hyundai(carId,carModel,carPrice);
                                }
                                listofCars.add(newCar);
                                c.setCarList((listofCars));
                            }
                        }
                        break;



                    case 3:
                        Collections.sort(list,new sortCustomer());
                        for(int i=0;i<list.size();i++){

                                System.out.println("customer Id: " + list.get(i).getId() + " Customer Name: " + list.get(i).getName());
                                for (Car car : list.get(i).getCarList())
                                {

                                    System.out.println(" Car Model : "+car.getCarModel()+" Car Price : "+car.getCarPrice()+" Car ID : "+car.getCarId()+" Resale price of car: "+car.getResalePrice());
                                }



                        }break;
                    case 4:
                              for(int i=0;i<list.size();i++) {
                                  System.out.println("customer Id: " + list.get(i).getId() + " Customer Name: " + list.get(i).getName());

                              }
                                break;
                    case 5:

                        for(int i=0;i<list.size();i++) {
                            System.out.println("customer Id: " + list.get(i).getId() );

                        }
                       Random random=new Random();
                       RandomId ri=new RandomId();
                       int random1[]=new int[6];
                       for(int i=0;i<6;i++){
                           int index=random.nextInt(list.size());
                           random1[i]=list.get(index).getId();
                       }
                       for (int i=0;i<6;i++){
                           if(random1[i]==ri.cid1){
                               System.out.println(" Congrats! ....Id: "+random1[i]+" You are the eligible for the prize");
                               break;
                           }
                          else if(random1[i]==ri.cid1){
                               System.out.println(" Congrats. . ...Id: "+random1[i]+"You are the eligible for the prize ");
                               break;
                           }
                          else if(random1[i]==ri.cid1){
                               System.out.println("Congrats......Id: "+random1[i]+" You are the eligible for the prize");
                               break;
                           }
                       }


                    break;
                    case 6:
                        break;
                }
            } while(admin_input != 6);

        }
        else
            {
            System.out.println("this id and password is incorrect");
        }

    }


}





