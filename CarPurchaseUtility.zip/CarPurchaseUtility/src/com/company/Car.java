package com.company;

import java.util.Scanner;

public abstract class Car{

    Scanner car=new Scanner(System.in);
    Scanner car1=new Scanner(System.in);
    int carId;
    String carModel;
    int carPrice;

    public int getCarId() {
        return carId;
    }
    public String getCarModel() {
        return carModel;
    }
    public int getCarPrice() {
        return carPrice;
    }
    abstract double getResalePrice();
}
